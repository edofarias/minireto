//: Playground - noun: a place where people can play
// reto, escribir par o impar, escribir  bingo cuando es multiplo de 5 y escribir #vivaSwift cuando está entre 30 y 40.
// Eduardo Farías

import UIKit

var a=1...29
for i in a{

    if i%2 == 0 && i%5 != 0{
        print("\(i)\t es par")
    }else if i%2 != 0 && i%5 != 0
    { print("\(i)\t es impar")
    }else if i%5 == 0{ print("\(i)\t BINGO")
    }else{
        print("\(i)\t #VivaSwift")
    }
}
var b=30...40
for j in b{
    print("\(j)\t #VivaSwift")
}
var c=41...100
for k in c{
    if k%2 == 0 && k%5 != 0{
        print("\(k)\t es par")
    }else if k%2 != 0 && k%5 != 0
    { print("\(k)\t es impar")
    }else if k%5 == 0{ print("\(k)\t BINGO")
    }else{
        print("\(k)\t #VivaSwift")
    }
}